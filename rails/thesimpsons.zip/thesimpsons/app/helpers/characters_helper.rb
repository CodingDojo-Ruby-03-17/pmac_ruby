module CharactersHelper
end
